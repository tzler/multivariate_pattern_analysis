function [net_lin] = integration_linear_train(inputs,targets)


% Define the neural network model
numInputs = length(inputs);
numOutputs = length(targets);
numLayers = 3;
biasConnect = logical([1 1 1]');
inputConnect = logical([1, 0; 0, 1;0 0]);
layerConnect = logical([0 0 0; 0 0 0; 1 1 0]);
outputConnect = logical([0 0 1]);

net_lin = network(numInputs,numLayers,biasConnect,inputConnect,layerConnect,outputConnect);

net_lin.layers{1}.size = 5;
net_lin.layers{1}.transferFcn = 'tansig';
net_lin.layers{2}.size = 5;
net_lin.layers{2}.transferFcn = 'tansig';
net_lin.layers{3}.size = numOutputs;
net_lin.trainFcn = 'traingd';

train(net_lin,X_lin,T);
