function mvpc_multiRegionIntegration(iSubject);

% Set inputs
subjects = [1,3,4,5,8,12:17];
regionLabels = {'PCaud'  'PCvis'  'facesOnly_roi'  'lSTG'  'lSTS'  'rSTG'  'rSTS'  'voiceOnly_roi'};
predictorRois = [3, 8];
predicteeRois = [1,2,4:7];
savePath = sprintf('/mindhive/saxelab3/anzellotti/facesVoices_art2/interactionModels_multimodalIntegration/subsub%02d_imodel.mat',subjects(iSubject));

% Load data for one subject
regionModel_fileName = sprintf('subsub%02d_rmodel01.mat',subjects(iSubject));
regionModel_filePath = fullfile('/mindhive/saxelab3/anzellotti/facesVoices_art2/regionModels_multimodalIntegration',regionModel_fileName);


nRoisTarget = length(predicteeRois);
nRoisInput = length(predictorRois);
nRuns = length(preprocdata{1});

for iRoi = 1:nRoisTarget  
    % Cross validate across runs
    for iRun = 1:nRuns
        % Format training and testing data for target regions
        training_targets = preprocdata{predicteeRois(iRoi)}{iRun}.train;
        testing_targets = preprocdata{predicteeRois(iRoi)}{iRun}.test;
        % Format training and testing data for predictor regions
        for jRoi = 1:nRoisInput
            training_inputs{jRoi} = preprocdata{predictorRois(jRoi)}{iRun}.train;
            testing_inputs{jRoi} = preprocdata{predictorRois(jRoi)}{iRun}.test;          
        end
        % Train and test model with linear integration of modalities
        net_lin = integration_linear_train(training_inputs,training_targets);
        varexpl_lin(iRoi,iRun) = integration_linear_test(net_lin,testing_inputs,testing_targets);
        % Train and test model with nonlinear integration of modalities
        net_nonlin = integration_nonlinear_train(training_inputs,training_targets);
        varexpl_nonlin(iRoi,iRun) = integration_nonlinear_test(net_lin,testing_inputs,testing_targets);
    end
end

save(savePath, 'net_lin','varexpl_lin','net_nonlin',' varexpl_nonlin','-v7.3');
