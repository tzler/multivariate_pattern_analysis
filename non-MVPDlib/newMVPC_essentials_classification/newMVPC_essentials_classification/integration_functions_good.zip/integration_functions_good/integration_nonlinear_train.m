function net_nonlin = integration_nonlinear_train(inputs_temp,targets)

inputs = [];
for iInput = 1:length(inputs_temp)
    inputs = vertcat(inputs,inputs_temp{iInput});
end

% Define the neural network model

numInputs = length(inputs);
numOutputs = length(targets);
numLayers = 2;
biasConnect = logical([1 1]');
inputConnect = logical([1; 0]);
layerConnect = logical([0 0; 1 0]);
outputConnect = logical([0 1]);

net_nonlin = network(numInputs,numLayers,biasConnect,inputConnect,layerConnect,outputConnect);

net_nonlin.layers{1}.size = 10;
net_nonlin.layers{1}.transferFcn = 'tansig';
net_nonlin.layers{2}.size = numOutputs;
net_nonlin.trainFcn = 'traingd';

train(net_nonlin,inputs,targets);
